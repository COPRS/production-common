#!/bin/bash

echo "Anfang"
if [ "$1" == "" ]
 then
	echo " Bitte geben sie die gewuenschte Anzahl von workdirs: z.B. ./makeWorkDir.sh 100"
	exit 1
fi	
rm -rf /data/ipf-s3/workdir*
i=1
while  [ $i -le $1 ]
	do
		mkdir -p /data/ipf-s3/workdir$i
		echo "mkdir -p /data/ipf-s3/workdir$i"
		i=`expr $i + 1`
	done	
	
echo "Ende"