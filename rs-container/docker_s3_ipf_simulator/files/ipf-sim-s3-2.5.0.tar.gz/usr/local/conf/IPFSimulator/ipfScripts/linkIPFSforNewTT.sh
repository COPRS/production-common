#!/bin/bash

TT_DIR=/usr/local/conf/IPFSimulator/TaskTables
IPF_COMPONENT_DIR=/usr/local/components
IPF_INSTANCE_DIR=/usr/local/conf/IPFSimulator

if [[ $EUID -ne 0 ]]
   then
   echo " This script must be run as root !"
   exit 1
fi 

if ! [ -d $TT_DIR ]
   then 
     echo "$TT_DIR is not exist !"
     exit 1
fi

for file in `find $TT_DIR -iname '*.xml'`
do
      
     #echo `basename $file`
     FILENAME=`grep '.bin' $file | grep -v "{ipf1home}"| cut -d'>' -f2 | cut -d'<' -f1`
     #echo $FILENAME
     for i in $FILENAME
     do 
        FOLDER=`dirname $i`
        LINK=`basename $i` 
        
        cd $IPF_COMPONENT_DIR
        mkdir -p $FOLDER
        cd $FOLDER 
        if ! [ -f $i -o -h $i ]
           then 
             ln -s $IPF_INSTANCE_DIR/bin/ipf-sim.sh $LINK
             echo "$LINK created"
        fi
        chown -R s3sysadm.S3sysadm ${FOLDER%/*}
        chmod -R 755  ${FOLDER%/*}

     done
done

echo "TaskTables create links end"



