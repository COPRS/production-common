#!/bin/bash
cd /data/ipf-s3/dsm/AUX/ || exit 1
for i in * 
do 
	mv $i/* ./
done
rm -rf ./TDS-*
for i in * 
do 
	touch /data/ipf-s3/dsm/.index/$i;
done
chmod ug+rwx -R ./ .index/
exit 0
