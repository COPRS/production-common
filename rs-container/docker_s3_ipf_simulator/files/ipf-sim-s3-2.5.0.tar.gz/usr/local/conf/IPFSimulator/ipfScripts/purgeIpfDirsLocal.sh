#!/bin/bash
IPFDATADIR="/data/ipf-s3"
echo "$(hostname): purging dirs in ${IPFDATADIR}..."
dirs_wrkdr=$(ls ${IPFDATADIR} | grep workdir)
dirs_count=$(ls ${IPFDATADIR} | grep workdir | wc -l)
#
 echo "removing $dirs_count workdirs in $IPFDATADIR"
for dir in ${dirs_wrkdr[@]} "ipf_analysis_tmp"
do
        cd ${IPFDATADIR}/$dir || exit 1
	rm -rf ./* || exit 1
done
#
echo "removing ${IPFDATADIR}/dsm"
cd "${IPFDATADIR}/dsm" || exit 1
for rm_dirs in $(ls | grep -v AUX )
do
        rm -rf ./${rm_dirs} || exit 1
	rm -rf ./.index || exit 1
done
#
echo "touching prods in ${IPFDATADIR}/dsm/.index"
mkdir -p "${IPFDATADIR}/dsm/.index" || exit 1
if [ -d "${IPFDATADIR}/dsm/AUX" ]
then
	cd "${IPFDATADIR}/dsm/AUX/" || exit 1
	for prod in *
	do
		touch "${IPFDATADIR}/dsm/.index/${prod}" 
	done
fi
echo "$(hostname): purging dirs in ${IPFDATADIR}...done"
exit 0
