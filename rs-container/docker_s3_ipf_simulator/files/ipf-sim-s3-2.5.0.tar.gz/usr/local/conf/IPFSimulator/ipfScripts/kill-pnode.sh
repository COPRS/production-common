#!/bin/bash
set -e
set -u

ps -fu s3sysadm | grep java | awk '{ print  $2 }' | xargs -I '{}' kill '{}'
