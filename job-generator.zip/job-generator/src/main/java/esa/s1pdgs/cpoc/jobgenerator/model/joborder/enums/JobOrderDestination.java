package esa.s1pdgs.cpoc.jobgenerator.model.joborder.enums;

/**
 * Available job order destination
 * @author Cyrielle Gailliard
 *
 */
public enum JobOrderDestination {
	DB, PROC;
}
